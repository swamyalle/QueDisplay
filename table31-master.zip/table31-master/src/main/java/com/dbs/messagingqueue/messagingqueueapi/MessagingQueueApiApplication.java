package com.dbs.messagingqueue.messagingqueueapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MessagingQueueApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(MessagingQueueApiApplication.class, args);
	}

}
