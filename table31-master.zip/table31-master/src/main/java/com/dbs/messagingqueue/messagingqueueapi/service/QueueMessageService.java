package com.dbs.messagingqueue.messagingqueueapi.service;

import com.dbs.messagingqueue.messagingqueueapi.entity.QueueInfo;

public interface QueueMessageService {

	public void createQueue(QueueInfo queueInfo);
}
