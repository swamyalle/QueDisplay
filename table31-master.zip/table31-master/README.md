# table31
Malleswarao
chandansingh
bora muddula naidu
alle swamy
ashwin
chamundeswari
deepthi
nagamuni reddy

#
Read Me 

This is  working solution for managing CURD operations on message ques.

Implemented using : spring boot+mysql+angular js

URL to test through postman :

create : provide message queu name and length of the queue.


Get : display all messages in each queue

Update :
	for a specific message queue id,we can update the content.

Delete : 
	Using this we can delete all messages from queue.

From IDE : 
	Run MessagingQueueApiApplication.java



steps to import & run the project..

1)Clone the project(https://github.com/dbshacktron27/table31)
2)import as existing Maven project
3)run-> run as java app/ spring boot app
